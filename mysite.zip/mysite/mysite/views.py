from django.http import HttpResponse
from django.shortcuts import render
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.utils.decorators import method_decorator
from django import forms
from django.views.decorators.csrf import csrf_exempt
from random import randint
from django.template import loader

bookings = []


@method_decorator(csrf_exempt)
def index(request):
    context = {}
    if request.method == 'POST':
        bus = request.POST.get('bus')
        date = request.POST.get('date')
        time = request.POST.get('time')
        source = request.POST.get('source')
        dest = request.POST.get('destination')
        fare = randint(1, 1000)
        context = {
            'bus': bus,
            'date': date,
            'time': time,
            'source': source,
            'destination': dest,
            'fare': fare,
        }
        if source == dest:
            template = loader.get_template('error.html')
            return HttpResponse(template.render({'message': "Source & Destination cities can't be the same!"}, request))

        else:
            template = loader.get_template('submit.html')
            bookings.append(context)
            print(bookings)
            return HttpResponse(template.render(context, request))


@method_decorator(csrf_exempt)
def landing(request):
    template = loader.get_template('index.html')
    return HttpResponse(template.render())


def crsf_exempt(args):
    pass


@method_decorator(crsf_exempt)
def showall(request):
    template = loader.get_template('showall.html')
    return HttpResponse(template.render(bookings, request))
