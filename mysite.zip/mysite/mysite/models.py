from django.db import models


# Create your models here.

class Booking(models.Model):
    bus = models.CharField(max_length=10)
    date = models.CharField(max_length=10)
    time = models.CharField(max_length=10)
    source = models.CharField(max_length=10)
    destination = models.CharField(max_length=10)

    def __str__(self):
        return self.bus
